<?php
session_start();
include 'db.php';

$message = '';

if(isset($_POST['signup'])){
    $name = mysqli_real_escape_string($conn, $_POST['user_name']);
    $email = mysqli_real_escape_string($conn, $_POST['user_email']);
    $phone = mysqli_real_escape_string($conn, $_POST['user_phone']);
    $password = mysqli_real_escape_string($conn, $_POST['user_pass']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($check) > 0){
        $message = "Email already registered!";
    } else {
        $insert = mysqli_query($conn, "INSERT INTO users (name,email,phone,password) VALUES('$name','$email','$phone','$hashed_password')");
        if($insert){
            $message = "Signup successful! <a href='login.php'>Login Now</a>";
        } else {
            $message = "Error! Try again later.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>HealthLingo - Signup</title>
<link rel="stylesheet" href="style.css" />
<style>
body { font-family: Arial; background:#f4f4f4; margin:0; }
.header { background-color: rgba(0, 77, 64, 0.9); padding:15px 0; position:sticky; top:0; z-index:10; }
.header-container { display:flex; justify-content:space-between; align-items:center; padding:0 5%; }
.logo { width:150px; height:auto; }
.nav a { color:#fff; text-decoration:none; margin:0 15px; font-weight:600; }
.nav a.active { border-bottom:2px solid white; }

.signup-container { min-height:80vh; display:flex; flex-direction:column; align-items:center; justify-content:flex-start; padding-top:60px; }
.signup-box { background: rgba(255,255,255,0.95); padding:30px 40px; border-radius:15px; box-shadow:0 4px 20px rgba(0,0,0,0.1); width:350px; text-align:center; }
.signup-box h2 { color:#004d40; margin-bottom:20px; }
.input-box { margin:8px 0; padding:10px; border:1px solid #ccc; border-radius:8px; font-size:14px; width:100%; }
.btn-signup { background:#00796b; color:white; border:none; padding:10px; border-radius:8px; font-weight:bold; width:100%; cursor:pointer; }
.btn-signup:hover { background:#004d40; }
.login-link a { color:#00796b; text-decoration:none; font-weight:bold; }
.login-link a:hover { text-decoration:underline; }
.message { color:red; margin:10px 0; font-size:14px; }
.footer-clean { padding:40px 0; background-color: rgba(106,205,185,0.9); color:#4b4c4d; text-align:center; }
.footer-clean .copyright { font-size:13px; opacity:0.6; }
</style>
</head>
<body>

<div class="header">
  <div class="header-container">
    <img src="images/logo.png" alt="HealthLingo Logo" class="logo" />
    <nav class="nav">
      <a href="homescreen.php">Home</a>
      <a href="login.php">Login</a>
      <a href="signup.php" class="active">Signup</a>
    </nav>
  </div>
</div>

<section class="signup-container">
  <div class="signup-box">
    <h2>Create Your Account</h2>
    <?php if($message != ''){ echo '<p class="message">'.$message.'</p>'; } ?>
    <form method="POST" autocomplete="off">
      <!-- Dummy hidden fields to prevent autofill -->
      <input type="text" style="display:none">
      <input type="password" style="display:none">

      <input type="text" name="user_name" class="input-box" placeholder="Full Name" required autocomplete="off">
      <input type="email" name="user_email" class="input-box" placeholder="Email" required autocomplete="off">
      <input type="text" name="user_phone" class="input-box" placeholder="Phone Number" required autocomplete="off">
      <input type="password" name="user_pass" class="input-box" placeholder="Password" required autocomplete="new-password">

      <button type="submit" name="signup" class="btn-signup">Register</button>
    </form>

    <div class="login-link" style="margin-top:10px;">
      Already have an account? <a href="login.php">Login Here</a>
    </div>
  </div>
</section>

<div class="footer-clean">
  <p class="copyright">© 2025 HealthLingo. All Rights Reserved.</p>
</div>

</body>
</html>
