<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

include 'db.php'; // DB connection
$user_id = $_SESSION['user_id'];

// Get report_id from GET parameter
$report_id = isset($_GET['report_id']) ? intval($_GET['report_id']) : 0;

// Fetch all reports for the logged-in user from medical_reports table
$stmt_reports = $conn->prepare("SELECT id, report_title FROM medical_reports WHERE user_id=?");
$stmt_reports->bind_param("i", $user_id);
$stmt_reports->execute();
$res_reports = $stmt_reports->get_result();
$reports = [];
while($row = $res_reports->fetch_assoc()){
    $reports[] = $row;
}

// If report_id is invalid, show selection of existing reports
if($report_id <= 0){
    echo "<h2>Select a Report to View/Share</h2>";
    if(empty($reports)){
        echo "<p>No reports available.</p>";
        exit();
    }
    echo "<ul>";
    foreach($reports as $r){
        echo '<li><a href="secure_sharing_screen.php?report_id=' . $r['id'] . '">' . htmlspecialchars($r['report_title']) . '</a></li>';
    }
    echo "</ul>";
    exit();
}

// Generate unique secure link
$secure_link = "https://secure.healthlingo.com/report/$report_id";

// Handle chat submission
if(isset($_POST['send_msg'])){
    $msg = trim($_POST['message']);
    if($msg != '' && $report_id > 0){
        $stmt = $conn->prepare("INSERT INTO report_chats (report_id, user_id, message) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $report_id, $user_id, $msg);
        $stmt->execute();
        // Redirect to avoid form resubmission
        header("Location: secure_sharing_screen.php?report_id=$report_id");
        exit();
    }
}

// Fetch messages for the selected report
$messages = [];
$stmt = $conn->prepare("SELECT rc.*, u.name FROM report_chats rc JOIN users u ON rc.user_id = u.id WHERE rc.report_id=? ORDER BY rc.created_at ASC");
$stmt->bind_param("i", $report_id);
$stmt->execute();
$res = $stmt->get_result();
while($row = $res->fetch_assoc()){
    $messages[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Secure Sharing</title>
<style>
/* Your existing CSS here */
body { margin:0; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background:url("images/Patientbg.png") no-repeat center center fixed; background-size:cover; display:flex; height:100vh; overflow:hidden; color:#004d40;}
.sidebar { width:250px; background: rgba(0,121,107,0.85); color:white; display:flex; flex-direction:column; padding:20px;}
.sidebar h2 { margin-bottom:20px; font-size:20px;}
.links { margin-top:auto;}
.links .back-btn { margin-top:20px; display:inline-block; padding:10px 20px; background:white; color: rgba(0,121,107,0.85); border:none; border-radius:5px; cursor:pointer; font-weight:bold; text-align:center; width:100%;}
.links .back-btn:hover { background:#e0f2f1;}
.main { flex:1; padding:30px; overflow-y:auto; display:flex; flex-direction:column; background: rgba(255,255,255,0.3); border-top-left-radius:25px; border-bottom-left-radius:25px; backdrop-filter:blur(5px);}
h1 { color: rgba(0,121,107,0.85); margin-bottom:20px;}
.sharing-container { background: rgba(255,255,255,0.8); padding:20px; border-radius:10px; max-width:500px; box-shadow:0 2px 5px rgba(0,0,0,0.1);}
.link-box { display:flex; align-items:center; background:#fff; border:1px solid #ccc; border-radius:5px; overflow:hidden; margin-bottom:15px;}
.link-box input { border:none; padding:10px; flex:1; font-size:14px; outline:none;}
.link-box button { padding:10px 15px; border:none; background: rgba(0,121,107,0.85); color:white; cursor:pointer; font-weight:bold;}
.link-box button:hover { background:#004d40;}
.chat-section { margin-top:20px;}
.chat-section h2 { font-size:18px; margin-bottom:10px; color: rgba(0,121,107,0.85);}
.chat-box { border:1px solid #ccc; border-radius:5px; height:150px; background:white; padding:10px; overflow-y:auto; margin-bottom:10px; font-size:14px;}
.chat-input { display:flex; gap:10px;}
.chat-input input { flex:1; padding:8px; border-radius:5px; border:1px solid #ccc;}
.chat-input button { padding:8px 15px; background: rgba(0,121,107,0.85); border:none; color:white; font-weight:bold; border-radius:5px; cursor:pointer;}
.chat-input button:hover { background:#004d40;}
</style>
</head>
<body>

<div class="sidebar">
<h2>HealthLingo</h2>
<div class="links">
  <button class="back-btn" onclick="window.location.href='patient_dashboard.php'">⬅ Back to Dashboard</button>
</div>
</div>

<div class="main">
<h1>Secure Sharing</h1>
<div class="sharing-container">
  <p>Share your simplified health report securely with your doctor or family:</p>
  <div class="link-box">
    <input type="text" value="<?php echo $secure_link; ?>" readonly>
    <button onclick="copyLink()">Copy</button>
  </div>

  <div class="chat-section">
    <h2>Chat / Comments</h2>
    <div class="chat-box" id="chatBox">
      <?php foreach($messages as $m): ?>
        <p><strong><?php echo htmlspecialchars($m['name']); ?>:</strong> <?php echo htmlspecialchars($m['message']); ?></p>
      <?php endforeach; ?>
    </div>
    <form method="post" class="chat-input">
      <input type="text" name="message" id="chatMessage" placeholder="Type a message..." required>
      <button type="submit" name="send_msg">Send</button>
    </form>
  </div>
</div>
</div>

<script>
function copyLink() {
  const linkInput = document.querySelector('.link-box input');
  linkInput.select();
  linkInput.setSelectionRange(0, 99999);
  document.execCommand("copy");
  alert("Link copied to clipboard!");
}
</script>

</body>
</html>