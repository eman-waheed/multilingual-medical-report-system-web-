<?php 
session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>HealthLingo - Multilingual Medical Report Simplifier</title>
  <link rel="stylesheet" href="style.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css" />
  <style>
    .btn-login {
      padding: 8px 15px;
      background: #00796b;
      color: #fff !important;
      border-radius: 5px;
      font-weight: 600;
      margin-left: 10px;
      transition: background 0.3s;
      text-decoration: none;
    }
    .btn-login:hover { background: #004d40; color: #fff !important; }

    /* Guide Section */
    .guide-section { background:#eaf7f3; padding:30px 0; margin-bottom:30px; border-radius:10px; }
    .guide-section h2 { text-align:center; color:#004d40; margin-bottom:20px; }
    .tab-btn { background:#00796b; color:white; border:none; padding:8px 15px; margin-right:5px; border-radius:5px; cursor:pointer; font-weight:600; }
    .tab-btn.active { background:#004d40; }
    .guide-content p { margin:10px 0; line-height:1.6; color:#004d40; }
  </style>
</head>
<body>

<!-- Header -->
<header class="header" id="home">
  <div class="container header-container">
    <img src="images/logo.png" alt="HealthLingo Logo" class="logo" />
    <nav class="nav">
      <a href="#home">Home</a>
      <a href="#about">About</a>
      <a href="#features">Features</a>
      <a href="#guide">How to Use</a>
      <a href="#contact">Contact</a>

      <?php
      if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
        <a href="admin-panel.php" class="btn-login">Admin Panel</a>
        <a href="logout.php" class="btn-login">Logout</a>
      <?php elseif(isset($_SESSION['role']) && $_SESSION['role'] == 'patient'): ?>
        <a href="patient_dashboard.php" class="btn-login">Dashboard</a>
        <a href="logout.php" class="btn-login">Logout</a>
      <?php else: ?>
        <a href="login.php" class="btn-login">Login / Register</a>
        <a href="admin-login.php" class="btn-login">Admin</a>
      <?php endif; ?>
    </nav>
  </div>
</header>

<!-- Hero Section -->
<section class="hero">
  <div class="hero-content">
    <h1>HealthLingo</h1>
    <h4><i>Know More. Worry Less.</i></h4>
    <p>Simplifying healthcare communication for every patient. Because understanding your health should be effortless.</p>
  </div>
</section>

<!-- How to Use Guide Section -->
<section class="guide-section" id="guide">
  <div class="container">
    <h2>How to Use HealthLingo</h2>

    <!-- Language Tabs -->
    <div class="guide-tabs mb-3">
      <button class="tab-btn active" data-lang="en">English</button>
      <button class="tab-btn" data-lang="ur">Urdu</button>
      <button class="tab-btn" data-lang="pa_shahmukhi">Punjabi (Shahmukhi)</button>
    </div>

    <!-- Guide Content -->
    <div class="guide-content p-3 border rounded" id="guideContent">
      <!-- Default content loaded by JS -->
    </div>
  </div>
</section>

<!-- Features Section -->
<section class="features-section" id="features">
  <h2>Our Key Features</h2>
  <div class="feature-cards">
    <div class="card" style="background-image: url('images/bg.png');">
      <div class="overlay">
        <h3>Smart Report Analysis</h3>
        <p>Automatically interpret medical data to generate clear, actionable insights.</p>
      </div>
    </div>
    <div class="card" style="background-image: url('images/multilingual.png');">
      <div class="overlay">
        <h3>Multilingual Support</h3>
        <p>Generate reports in multiple languages for inclusivity and accessibility.</p>
      </div>
    </div>
    <div class="card" style="background-image: url('images/dictionary.png');">
      <div class="overlay">
        <h3>Medical Dictionary</h3>
        <p>Quickly look up medical terms and abbreviations to better understand reports and prescriptions.</p>
      </div>
    </div>
    <div class="card" style="background-image: url('images/severity level.png');">
      <div class="overlay">
        <h3>Severity Level Indicator</h3>
        <p>Automatically highlights the severity of medical conditions based on report data to assist quick assessment.</p>
      </div>
    </div>
    <div class="card" style="background-image: url('images/chatbot.png');">
      <div class="overlay">
        <h3>Basic Healthcare Assistant</h3>
        <p>Get quick advice, preventive care tips, and reminders to maintain a healthy daily routine.</p>
      </div>
    </div>
    <div class="card" style="background-image: url('images/Visual.png');">
      <div class="overlay">
        <h3>Visualization Feature</h3>
        <p>Transform medical data into clear, interactive visuals — making it easier to understand trends and health insights at a glance.</p>
      </div>
    </div>
  </div>
</section>

<!-- About Section -->
<section class="about" id="about">
  <div class="section-container">
    <h2>About HealthLingo</h2>
    <p>
      <strong>HealthLingo</strong> is a multilingual medical report simplifier that helps patients easily understand complex medical terms.
      We translate your reports into <b>Urdu</b> and <b>Punjabi</b>, explain key findings in simple language, and even visualize your health data for better clarity.
      <br><br>
      Our goal is to make healthcare communication <em>clear, inclusive, and empowering</em> — helping you take charge of your health with confidence.
    </p>
  </div>
</section>

<!-- Contact Section -->
<section class="contact" id="contact">
  <div class="overlay-box">
    <h2>Contact Us</h2>
    <form class="contact-form" action="contact_process.php" method="post">
      <input type="text" name="name" placeholder="Your Name" required />
      <input type="email" name="email" placeholder="Your Email" required />
      <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
      <button type="submit">Send Message</button>
    </form>
  </div>
</section>

<!-- Footer -->
<div class="footer-clean">
  <footer>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-sm-4 col-md-3 item">
          <h3>Features</h3>
          <ul>
            <li><a href="#">Multilingual Support</a></li>
            <li><a href="#">Medical Dictionary</a></li>
            <li><a href="#">Severity Level Detection</a></li>
            <li><a href="#">Data Visualization</a></li>
          </ul>
        </div>
        <div class="col-sm-4 col-md-3 item">
          <h3>Resources</h3>
          <ul>
            <li><a href="#">Documentation</a></li>
            <li><a href="#">Research References</a></li>
            <li><a href="#">API Integration Guide</a></li>
          </ul>
        </div>
        <div class="col-lg-3 item social">
          <a href="#"><i class="icon ion-social-linkedin"></i></a>
          <a href="#"><i class="icon ion-social-github"></i></a>
          <a href="#"><i class="icon ion-social-instagram"></i></a>
          <p class="copyright">Multilingual Medical Report Assistant © 2025</p>
        </div>
      </div>
    </div>
  </footer>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>

<!-- Guide JS -->
<script>
const guides = {
  en: `
    <p><strong>Step 1:</strong> Upload your medical report (PDF, DOCX, or TXT) using the "Upload Report" section in your dashboard.</p>
    <p><strong>Step 2:</strong> Choose the language you want your report translated into (English, Urdu, Punjabi Shahmukhi).</p>
    <p><strong>Step 3:</strong> Download your original or translated report.</p>
    <p><strong>Step 4:</strong> Use the Visualization module to see highlighted organs and quick health insights.</p>
    <p><strong>Step 5:</strong> Look up any difficult terms in the Medical Dictionary for better understanding.</p>
    <p><strong>Step 6:</strong> Check the severity level indicator to know if your report shows mild, moderate, or severe conditions.</p>
    <p><strong>Step 7:</strong> You can always switch languages anytime using the dropdown to see the translation immediately.</p>
    <p><strong>Tip:</strong> Stay informed on alerts like seasonal diseases and preventive tips through the ongoing updates section.</p>
  `,
  ur: `
    <p><strong>مرحلہ 1:</strong> اپنی میڈیکل رپورٹ (PDF، DOCX، یا TXT) "اپلوڈ رپورٹ" سیکشن میں اپلوڈ کریں۔</p>
    <p><strong>مرحلہ 2:</strong> اس زبان کا انتخاب کریں جس میں آپ رپورٹ کا ترجمہ چاہتے ہیں (انگریزی، اردو، پنجابی شاہ مکھی)۔</p>
    <p><strong>مرحلہ 3:</strong> اصل یا ترجمہ شدہ رپورٹ ڈاؤن لوڈ کریں۔</p>
    <p><strong>مرحلہ 4:</strong> Visualization ماڈیول میں اجزاء اور فوری صحت کے مشورے دیکھیں۔</p>
    <p><strong>مرحلہ 5:</strong> کسی بھی مشکل اصطلاح کے لیے Medical Dictionary استعمال کریں۔</p>
    <p><strong>مرحلہ 6:</strong> Severity Level Indicator سے معلوم کریں کہ رپورٹ میں ہلکی، درمیانی یا شدید حالت ہے۔</p>
    <p><strong>مرحلہ 7:</strong> آپ کسی بھی وقت زبان بدل سکتے ہیں اور فوراً ترجمہ دیکھ سکتے ہیں۔</p>
    <p><strong>مشورہ:</strong> موسمی بیماریوں اور احتیاطی نکات کے بارے میں جاری اپ ڈیٹس دیکھیں۔</p>
  `,
  pa_shahmukhi: `
    <p><strong>قدم 1:</strong> اپنی میڈیکل رپورٹ (PDF, DOCX, TXT) "اپلوڈ رپورٹ" سیکشن وچ اپلوڈ کرو۔</p>
    <p><strong>قدم 2:</strong> اوہ زبان منتخب کرو جس وچ تُسیں رپورٹ دا ترجمہ دیکھنا چاندے او (انگریزی، اردو، پنجابی شاہ مکھی)۔</p>
    <p><strong>قدم 3:</strong> اصلی یا ترجمہ شدہ رپورٹ ڈاؤن لوڈ کرو۔</p>
    <p><strong>قدم 4:</strong> Visualization ماڈیول وچ اجزاء تے صحت دے مشورے دیکھو۔</p>
    <p><strong>قدم 5:</strong> کسی وی مشکل اصطلاح لئی Medical Dictionary استعمال کرو۔</p>
    <p><strong>قدم 6:</strong> Severity Level Indicator نال دیکھو کہ رپورٹ وچ حالت ہلکی، درمیانی یا شدید اے۔</p>
    <p><strong>قدم 7:</strong> تُسیں ہر وقت زبان بدل سکدے او تے فوراً ترجمہ دیکھ سکدے او۔</p>
    <p><strong>مشورہ:</strong> موسمی بیماریوں تے حفاظتی نکات بارے جاری اپ ڈیٹس دیکھو۔</p>
  `
};

// Load default guide (English)
document.getElementById('guideContent').innerHTML = guides['en'];

// Tab switching
document.querySelectorAll('.tab-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
        document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        const lang = btn.getAttribute('data-lang');
        document.getElementById('guideContent').innerHTML = guides[lang];
    });
});
</script>

</body>
</html>
