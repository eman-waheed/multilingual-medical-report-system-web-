<?php
session_start();
include 'db.php';

$message = '';

if(isset($_POST['login'])){
    $email = mysqli_real_escape_string($conn, $_POST['user_email']);
    $password = mysqli_real_escape_string($conn, $_POST['user_pass']);

    $query = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($query) > 0){
        $user = mysqli_fetch_assoc($query);
        if(password_verify($password, $user['password'])){
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            header("Location: patient_dashboard.php");
            exit();
        } else {
            $message = "Incorrect password!";
        }
    } else {
        $message = "No account found with this email!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>HealthLingo - User Login</title>
<link rel="stylesheet" href="style.css" />
<style>
body { font-family: Arial; background:#f4f4f4; margin:0; }
.header { background-color: rgba(0, 77, 64, 0.9); padding:15px 0; position:sticky; top:0; z-index:10; }
.header-container { display:flex; justify-content:space-between; align-items:center; padding:0 5%; }
.logo { width:150px; height:auto; }
.nav a { color:#fff; text-decoration:none; margin:0 15px; font-weight:600; }
.nav a.active { border-bottom:2px solid white; }

.login-container { min-height:80vh; display:flex; flex-direction:column; align-items:center; justify-content:flex-start; padding-top:60px; }
.login-box { background: rgba(255,255,255,0.95); padding:30px 40px; border-radius:15px; box-shadow:0 4px 20px rgba(0,0,0,0.1); width:350px; text-align:center; }
.login-box h2 { color:#004d40; margin-bottom:20px; }
.input-box { margin:8px 0; padding:10px; border:1px solid #ccc; border-radius:8px; font-size:14px; width:100%; }
.btn-login { background:#00796b; border:none; padding:10px 0; border-radius:8px; font-weight:bold; width:100%; cursor:pointer; color:white; }
.message { color:red; margin:10px 0; font-size:14px; }
.forgot a, .signup-link a { color:#00796b; text-decoration:none; font-weight:600; }
.footer-clean { padding:40px 0; background-color: rgba(106,205,185,0.9); color:#4b4c4d; text-align:center; }
.footer-clean .copyright { font-size:13px; opacity:0.6; }
</style>
</head>
<body>

<div class="header">
  <div class="header-container">
    <img src="images/logo.png" alt="HealthLingo Logo" class="logo" />
    <nav class="nav">
      <a href="homescreen.php">Home</a>
      <a href="login.php" class="active">Login</a>
      <a href="signup.php">Register</a>
    </nav>
  </div>
</div>

<section class="login-container">
  <div class="login-box">
    <h2>User Login</h2>
    <?php if($message != ''){ echo '<p class="message">'.$message.'</p>'; } ?>
    <form method="POST" autocomplete="off">
      <!-- Dummy hidden fields to prevent autofill -->
      <input type="text" style="display:none">
      <input type="password" style="display:none">

      <input type="email" name="user_email" class="input-box" placeholder="Email" required autocomplete="off">
      <input type="password" name="user_pass" class="input-box" placeholder="Password" required autocomplete="new-password">

      <button type="submit" name="login" class="btn-login">Login</button>
    </form>

    <div class="forgot" style="margin-top:10px;">
      <a href="forgot.php">Forgot Password?</a>
    </div>

    <div class="signup-link" style="margin-top:10px;">
      Don’t have an account? <a href="signup.php">Register Now</a>
    </div>
  </div>
</section>

<div class="footer-clean">
  <p class="copyright">© 2025 HealthLingo. All Rights Reserved.</p>
</div>

</body>
</html>
