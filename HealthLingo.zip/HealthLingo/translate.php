<?php
// translate.php
include 'db.php'; // your DB connection
require __DIR__ . '/vendor/autoload.php'; // for Google Translate client

use Stichoza\GoogleTranslate\GoogleTranslate;

// Fetch all reports that are not yet translated
$query = "SELECT id, report_file FROM medical_reports WHERE translated_text_ur IS NULL OR translated_text_pa IS NULL";
$result = mysqli_query($conn, $query);

if($result){
    $tr = new GoogleTranslate(); // default from auto-detect

    while($row = mysqli_fetch_assoc($result)){
        $report_id = $row['id'];
        $text = $row['report_file'];

        // Translate to Urdu
        $tr->setTarget('ur');
        $translated_ur = $tr->translate($text);

        // Translate to Punjabi
        $tr->setTarget('pa');
        $translated_pa = $tr->translate($text);

        // Update DB
        $stmt = $conn->prepare("UPDATE medical_reports SET translated_text_ur=?, translated_text_pa=? WHERE id=?");
        $stmt->bind_param("ssi", $translated_ur, $translated_pa, $report_id);
        $stmt->execute();
        $stmt->close();
    }
    echo "Translation completed!";
} else {
    echo "No reports found for translation.";
}

$conn->close();
?>
