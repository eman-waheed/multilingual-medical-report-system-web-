<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

include 'db.php';
require 'vendor/autoload.php';

use PhpOffice\PhpWord\IOFactory;
use Smalot\PdfParser\Parser as PdfParser;
use Stichoza\GoogleTranslate\GoogleTranslate;

$user_id = $_SESSION['user_id'];
$upload_msg = "";

ini_set('max_execution_time', '300');  // Allow long scripts

/*--------------------------------------
    FILE UPLOAD
---------------------------------------*/
if(isset($_POST['upload'])){
    if(isset($_FILES['report_file']) && $_FILES['report_file']['error'] == 0){

        $file_name = $_FILES['report_file']['name'];
        $file_tmp = $_FILES['report_file']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $allowed = ['pdf','doc','docx','txt'];
        if(in_array($file_ext, $allowed)){
            
            $new_name = time().'_'.$file_name;
            $upload_dir = 'uploads/';

            if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

            move_uploaded_file($file_tmp, $upload_dir.$new_name);

            // Save to DB
            $stmt = $conn->prepare("INSERT INTO medical_reports (user_id, report_title, report_file, severity) VALUES (?, ?, ?, ?)");
            $severity = "mild";
            $stmt->bind_param("isss", $user_id, $file_name, $new_name, $severity);
            $stmt->execute();

            $upload_msg = "Report uploaded successfully!";
        } else {
            $upload_msg = "Invalid file type!";
        }
    }
}

/*--------------------------------------
    FETCH REPORTS
---------------------------------------*/
$reports = [];
$result = mysqli_query($conn, "SELECT * FROM medical_reports WHERE user_id = $user_id ORDER BY created_at DESC LIMIT 5");
if($result){
    while($row = mysqli_fetch_assoc($result)){
        $reports[] = $row;
    }
}

/*--------------------------------------
    SEVERITY COLOR
---------------------------------------*/
function getSeverityClass($sev){
    switch($sev){
        case 'mild': return ['green', 'Normal'];
        case 'moderate': return ['yellow', 'Moderate'];
        case 'severe': return ['red', 'Severe'];
        default: return ['green', 'Normal'];
    }
}

/*--------------------------------------
    FILE TEXT EXTRACTION
---------------------------------------*/
function extractText($filepath, $ext){
    $text = "";
    try{
        if($ext == 'pdf'){
            $parser = new PdfParser();
            $pdf = $parser->parseFile($filepath);
            $text = $pdf->getText();

        } elseif($ext == 'doc' || $ext == 'docx'){
            $phpWord = IOFactory::load($filepath);
            foreach($phpWord->getSections() as $section){
                foreach($section->getElements() as $el){
                    if(method_exists($el, 'getText'))
                        $text .= $el->getText()." ";
                }
            }
        } elseif($ext == 'txt'){
            $text = file_get_contents($filepath);
        }
    } catch(Exception $e){
        return "";
    }
    return $text;
}

/*--------------------------------------
    GURMUKHI → SHAHMUKHI FUNCTION
---------------------------------------*/
function gurmukhiToShahmukhi($text){
    $map = [
        'ਅ'=>'ا','ਆ'=>'آ','ਇ'=>'اِ','ਈ'=>'ای','ਉ'=>'او','ਊ'=>'اُو',
        'ਏ'=>'اے','ਐ'=>'آے','ਓ'=>'او','ਔ'=>'اؤ',
        'ਕ'=>'ک','ਖ'=>'کھ','ਗ'=>'گ','ਘ'=>'گھ','ਙ'=>'نگ',
        'ਚ'=>'چ','ਛ'=>'چھ','ਜ'=>'ج','ਝ'=>'جھ','ਞ'=>'نج',
        'ਟ'=>'ٹ','ਠ'=>'ٹھ','ਡ'=>'ڈ','ਢ'=>'ڈھ','ਣ'=>'ن',
        'ਤ'=>'ت','ਥ'=>'تھ','ਦ'=>'د','ਧ'=>'دھ','ਨ'=>'ن',
        'ਪ'=>'پ','ਫ'=>'ف','ਬ'=>'ب','ਭ'=>'بھ','ਮ'=>'م',
        'ਯ'=>'ی','ਰ'=>'ر','ਲ'=>'ل','ਵ'=>'و',
        'ਸ'=>'س','ਹ'=>'ہ',
        'ਖ਼'=>'خ','ਗ਼'=>'غ','ਜ਼'=>'ز','ਫ਼'=>'ف','ਸ਼'=>'ش',
        'ਾ'=>'ا','ਿ'=>'ِ','ੀ'=>'ی','ੁ'=>'ُ','ੂ'=>'ُو',
        'ੇ'=>'ے','ੈ'=>'َے','ੋ'=>'و','ੌ'=>'ؤ','ੰ'=>'ں','ਂ'=>'ں','ੱ'=>'ّ'
    ];

    return strtr($text, $map);
}

/*--------------------------------------
    TRANSLATION FUNCTION
---------------------------------------*/
function translateLargeText($text, $lang){
    $tr = new GoogleTranslate();

    if($lang == "en" || $lang == "ur"){
        $tr->setTarget($lang);
        return $tr->translate($text);
    }

    if($lang == "pa_shahmukhi"){
        $tr->setTarget("pa"); // Gurmukhi
        $gurmukhi = $tr->translate($text);
        return gurmukhiToShahmukhi($gurmukhi);
    }

    return $text; // fallback
}

$lang = $_GET['lang'] ?? 'en';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Report Upload & Translation</title>
<style>
body { margin:0; font-family:Verdana; background:#f4f4f4; display:flex; height:100vh; overflow:hidden; color:#004d40;}
.sidebar { width:250px; background:#00796b; color:white; padding:20px; }
.sidebar h2 { margin-bottom:20px; }
.links a, .back-btn, .links button { display:block; margin:10px 0; background:white; color:#00796b; padding:10px; border-radius:5px; text-align:center; font-weight:bold; text-decoration:none; cursor:pointer;}
.main { flex:1; padding:30px; overflow-y:auto;}
.upload-card, .result-card { background:white; padding:20px; border-radius:10px; margin-top:15px; }
.actions a { background:#00796b; color:white; padding:7px 10px; border-radius:5px; text-decoration:none; margin-right:5px;}
.severity.green { background:#4caf50; color:white; padding:10px; border-radius:5px; }
.severity.yellow { background:#ffeb3b; color:black; padding:10px; border-radius:5px; }
.severity.red { background:#f44336; color:white; padding:10px; border-radius:5px; }
</style>
</head>

<body>

<div class="sidebar">
<h2>HealthLingo</h2>
<div class="links">
    <a href="patient_dashboard.php">Dashboard</a>
    <a href="visualization.php">Visualization</a>
    <a href="feedback.php">Feedback</a>
    <button class="back-btn" onclick="window.location.href='patient_dashboard.php'">⬅ Back</button>
</div>
</div>

<div class="main">

<h1>Report Upload & Translation</h1>

<?php if($upload_msg != "") echo "<p style='color:green;font-weight:bold;'>$upload_msg</p>"; ?>

<div class="upload-card">
<h3>Upload Report</h3>
<form method="post" enctype="multipart/form-data">
    <input type="file" name="report_file" required><br><br>
    <button type="submit" name="upload">Upload</button>
</form>
</div>

<hr><br>

<h2>Select Language for Translation</h2>

<form method="GET">
    <select name="lang">
        <option value="en" <?= $lang=='en'?'selected':''; ?>>English</option>
        <option value="ur" <?= $lang=='ur'?'selected':''; ?>>Urdu</option>
        <option value="pa_shahmukhi" <?= $lang=='pa_shahmukhi'?'selected':''; ?>>Punjabi (Urdu Script)</option>
    </select>
    <button type="submit">Apply</button>
</form>

<div class="result-section">

<?php if(count($reports) > 0): ?>
    <?php foreach($reports as $r): 
        list($cls, $txt) = getSeverityClass($r['severity']); 
        $filepath = 'uploads/'.$r['report_file'];
        $ext = strtolower(pathinfo($r['report_file'], PATHINFO_EXTENSION));
        $original_text = extractText($filepath, $ext);

        // Translate only if needed
        $translated_text = translateLargeText($original_text, $lang);

        $translated_file = "uploads/".$user_id."_".time()."_$lang.txt";
        file_put_contents($translated_file, $translated_text);
    ?>

    <div class="result-card">
        <h3><?= htmlspecialchars($r['report_title']); ?></h3>
        <div class="severity <?= $cls; ?>"><?= $txt; ?></div>

        <div class="actions">
            <a href="<?= $filepath; ?>" download>Download Original</a>
            <a href="<?= $translated_file; ?>" download>Download (<?= strtoupper($lang); ?>)</a>
        </div>
    </div>

    <?php endforeach; ?>
<?php else: ?>
    <div class="result-card">No reports found.</div>
<?php endif; ?>

</div>

</div>
</body>
</html>
