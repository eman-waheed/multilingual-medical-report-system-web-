<?php
session_start();
include 'db.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch user info
$user_id = $_SESSION['user_id'];
$result = mysqli_query($conn, "SELECT * FROM users WHERE id='$user_id'");
$user = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HealthLingo - Dashboard</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .dashboard {
      min-height: 80vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      animation: fadeIn 1s ease-in;
      color: #004d40;
    }
    .dashboard h2 { margin-bottom: 15px; }
    .btn {
      background-color: #00796b;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
    }
    .btn:hover { background-color: #004d40; }
  </style>
</head>
<body>

  <!-- Header -->
  <div class="header">
    <div class="header-container">
      <img src="images/logo.png" alt="HealthLingo Logo" class="logo" />
      <nav class="nav">
        <a href="homescreen.php">Home</a>
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="logout.php">Logout</a>
      </nav>
    </div>
  </div>

  <!-- Dashboard Content -->
  <div class="dashboard">
    <h2>Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h2>
    <p>You’re successfully logged in as a HealthLingo user!</p>
    <button class="btn" onclick="window.location.href='homescreen.php'">Go to Home</button>
  </div>

  <!-- Footer -->
  <div class="footer-clean">
    <p class="copyright">© 2025 HealthLingo. All Rights Reserved.</p>
  </div>

</body>
</html>
