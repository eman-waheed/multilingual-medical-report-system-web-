<?php
session_start();
include 'db.php'; // your database connection

// If already logged in as admin, redirect to panel
if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'){
    header("Location: admin-panel.php");
    exit();
}

$message = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password']; // plain text from form

    // Fetch user with role = admin
    $sql = "SELECT * FROM users WHERE email='$email' AND role='admin' LIMIT 1";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) === 1){
        $admin = mysqli_fetch_assoc($result);

        // Verify password (assuming password is hashed)
        if(password_verify($password, $admin['password'])){
            $_SESSION['user_id'] = $admin['id'];
            $_SESSION['user_name'] = $admin['name'];
            $_SESSION['role'] = 'admin';

            header("Location: admin-panel.php");
            exit();
        } else {
            $message = "Incorrect password!";
        }
    } else {
        $message = "Admin account not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login - HealthLingo</title>
<style>
body { font-family: Arial, sans-serif; background:#f1f1f1; display:flex; justify-content:center; align-items:center; height:100vh; margin:0; }
.login-box { background:white; padding:30px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.2); width:350px; }
.login-box h2 { margin:0 0 20px 0; color:#00796b; text-align:center; }
.login-box input { width:100%; padding:10px; margin:10px 0; border-radius:5px; border:1px solid #ccc; }
.login-box button { width:100%; padding:10px; background:#00796b; color:white; border:none; border-radius:5px; cursor:pointer; font-weight:bold; }
.login-box button:hover { background:#004d40; }
.message { color:red; font-weight:bold; text-align:center; }
</style>
</head>
<body>
<div class="login-box">
    <h2>Admin Login</h2>
    <?php if($message != '') { echo "<div class='message'>$message</div>"; } ?>
    <form method="post" action="" autocomplete="off">
        <input type="email" name="email" placeholder="Admin Email" required autocomplete="off">
        <input type="password" name="password" placeholder="Password" required autocomplete="new-password">
        <button type="submit">Login</button>
    </form>
</div>
</body>
</html>
