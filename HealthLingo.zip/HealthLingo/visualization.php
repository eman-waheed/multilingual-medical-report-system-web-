<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$userName = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'User';

include 'db.php'; // mysqli $conn

// fetch recent reports for this user
$reports = [];
$stmt = $conn->prepare("SELECT id, report_title, report_file, created_at FROM medical_reports WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
while($r = $res->fetch_assoc()){
    $reports[] = $r;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Visualization Module - HealthLingo</title>
<style>
body { margin:0; font-family: "Segoe UI", Tahoma, Verdana, sans-serif; background:#f4f7f6; color:#004d40; }
.container { display:flex; min-height:100vh; }
.sidebar { width:260px; background:#00796b; color:#fff; padding:22px; box-sizing:border-box; }
.sidebar h2 { margin:0 0 14px 0; font-size:20px; }
.links a, .links button { display:block; margin:8px 0; background:#fff; color:#00796b; padding:8px 10px; text-decoration:none; border-radius:6px; font-weight:600; text-align:center; }
.main { flex:1; padding:28px; box-sizing:border-box; overflow:auto; }

.viz-card { background:rgba(255,255,255,0.98); border-radius:10px; padding:18px; box-shadow:0 4px 18px rgba(0,0,0,0.06); max-width:1150px; margin-bottom:18px; }
.controls { display:flex; gap:12px; align-items:center; margin-bottom:14px; flex-wrap:wrap; }
.select-report { padding:8px 10px; border-radius:6px; border:1px solid #cfd8d5; }
.btn { padding:8px 12px; border-radius:6px; background:#00796b; color:#fff; border:none; cursor:pointer; font-weight:700; }
.btn.secondary { background:#004d40; }
.status { font-size:14px; color:#00695c; margin-left:8px; }

.row { display:flex; gap:18px; align-items:flex-start; flex-wrap:wrap; }
.left { flex:0 0 580px; }
.right { flex:1; min-width:260px; }

.body-wrap { background:linear-gradient(180deg,#eaf7f3,#ffffff); border:1px solid #dbeeee; border-radius:10px; padding:12px; }
.body-model { width:100%; height:520px; display:flex; align-items:center; justify-content:center; }

.tips { background:#fff; border:1px solid #dbeeee; padding:12px; border-radius:8px; }
.tips h4 { margin:0 0 8px 0; color:#004d40; }
.tip-item { margin:8px 0; padding:10px; border-radius:6px; background:#f1f8f6; border-left:4px solid #00796b; }

.org { fill:#cdece6; stroke:#88c9bb; stroke-width:1; transition:all .25s ease; }
.org.active { fill:#ff8a80; stroke:#ff5252; filter: drop-shadow(0 6px 12px rgba(255,82,82,0.12)); transform-origin:center center; }
.org.pulse { animation: pulse 1s infinite; }
@keyframes pulse { 0%{ transform:scale(1); }50%{ transform:scale(1.06); }100%{ transform:scale(1); } }

#bodySvg { transition: transform .35s ease; transform-origin:center center; }
#extractedText { width:100%; height:120px; padding:8px; border-radius:6px; border:1px solid #e0efea; background:#fbfffe; overflow:auto; white-space:pre-wrap; }

@media(max-width:900px){
  .left{flex-basis:100%}
  .right{flex-basis:100%}
}
</style>
</head>
<body>
<div class="container">
  <div class="sidebar">
    <h2>HealthLingo</h2>
    <div style="margin-bottom:8px;">Hello, <strong><?php echo htmlspecialchars($userName); ?></strong></div>
    <div class="links">
      <a href="patient_dashboard.php">Dashboard</a>
      <a href="report_upload.php">Reports</a>
      <a href="logout.php">Logout</a>
    </div>
  </div>

  <div class="main">
    <div class="viz-card">
      <div class="controls">
        <select id="reportSelect" class="select-report">
          <option value="">-- Select a report --</option>
          <?php foreach($reports as $rep): ?>
            <option value="<?php echo (int)$rep['id']; ?>" data-file="<?php echo htmlspecialchars($rep['report_file']); ?>">
              <?php echo htmlspecialchars($rep['report_title'] . ' — ' . date('Y-m-d', strtotime($rep['created_at']))); ?>
            </option>
          <?php endforeach; ?>
        </select>

        <!-- LANGUAGE SELECTION DROPDOWN -->
        <select id="langSelect" class="select-report">
          <option value="en" selected>English</option>
          <option value="ur">Urdu</option>
          <option value="pa">Punjabi</option>
        </select>

        <button id="btnHighlight" class="btn secondary">Highlight Organ</button>
        <button id="btnZoom" class="btn">Zoom</button>
        <button id="btnRotate" class="btn">Rotate</button>
        <button id="btnAnimate" class="btn">Animate</button>
        <span class="status" id="statusMsg">Choose a report to auto-detect keywords.</span>
      </div>

      <div class="row">
        <div class="left">
          <div class="body-wrap">
            <div class="body-model" id="bodyModel">
              <svg id="bodySvg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 520" width="100%" height="100%">
                <g id="brain" class="org" data-organ="brain"><ellipse cx="150" cy="52" rx="46" ry="36"></ellipse></g>
                <g id="leftLung" class="org" data-organ="lungs"><path d="M80 120 C60 140, 70 195, 90 220 L120 220 C100 195, 110 140, 90 120 Z"></path></g>
                <g id="rightLung" class="org" data-organ="lungs"><path d="M220 120 C240 140, 230 195, 210 220 L180 220 C200 195, 190 140, 210 120 Z"></path></g>
                <g id="heart" class="org" data-organ="heart"><path d="M150 170 C140 154, 120 150, 120 170 C120 190, 150 210, 150 210 C150 210, 180 190, 180 170 C180 150, 160 154, 150 170 Z"></path></g>
                <g id="liver" class="org" data-organ="liver"><ellipse cx="110" cy="280" rx="55" ry="28"></ellipse></g>
                <g id="stomach" class="org" data-organ="stomach"><path d="M200 285 C190 300, 180 320, 155 325 C140 327, 140 305, 150 295 C170 280, 195 275, 200 285 Z"></path></g>
                <g id="leftKidney" class="org" data-organ="kidneys"><ellipse cx="100" cy="340" rx="20" ry="12"></ellipse></g>
                <g id="rightKidney" class="org" data-organ="kidneys"><ellipse cx="200" cy="340" rx="20" ry="12"></ellipse></g>
                <g id="pelvis" class="org" data-organ="bones"><path d="M120 390 C110 405, 115 430, 150 430 C185 430, 190 405, 180 390 Z"></path></g>
                <g id="leftLeg" class="org" data-organ="bones"><rect x="130" y="430" width="20" height="70" rx="8"></rect></g>
                <g id="rightLeg" class="org" data-organ="bones"><rect x="150" y="430" width="20" height="70" rx="8"></rect></g>
                <style>text.orgLabel { font-size:10px; fill:#004d40; opacity:0.8; }</style>
                <text x="148" y="45" class="orgLabel" text-anchor="middle">Brain</text>
                <text x="150" y="172" class="orgLabel" text-anchor="middle">Heart</text>
              </svg>
            </div>
          </div>
        </div>

        <div class="right">
          <div class="tips">
            <h4>Detected issues & tips</h4>
            <div id="tipsList"><em>No report selected.</em></div>
          </div>

          <div style="height:12px"></div>

          <div class="tips">
            <h4>Extracted / scanned text</h4>
            <div id="extractedText">No text loaded.</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
// language translations
const LANG = {
  en: { chooseReport:'Choose a report to auto-detect keywords.', noReport:'No report selected.', detecting:'Detecting keywords...', noKeywords:'No specific organ detected.', generalTip:'General health: stay hydrated, balanced diet, regular exercise, routine checkups.', animateNone:'No organ to animate.', highlighted:'Highlighted: ', animating:'Animating: ', animationStopped:'Animation stopped.', zoom:'Zoom', resetZoom:'Reset Zoom', rotate:'Rotate', resetRotate:'Reset Rotate', highlight:'Highlight Organ', animate:'Animate' },
  ur: { chooseReport:'رپورٹ منتخب کریں تاکہ کلیدی الفاظ خودکار طور پر پتہ چل جائیں۔', noReport:'کوئی رپورٹ منتخب نہیں کی گئی۔', detecting:'کلیدی الفاظ کا پتہ چل رہا ہے...', noKeywords:'کوئی مخصوص عضو نہیں ملا۔', generalTip:'عمومی صحت: پانی زیادہ پئیں، متوازن غذا، باقاعدہ ورزش، معمول کے چیک اپ۔', animateNone:'کوئی عضو حرکت دینے کے لیے نہیں۔', highlighted:'نمایاں شدہ: ', animating:'حرکت دے رہا ہے: ', animationStopped:'حرکت ختم ہوگئی۔', zoom:'زوم', resetZoom:'زوم ری سیٹ', rotate:'گھمائیں', resetRotate:'گھمانا ری سیٹ', highlight:'عضو نمایاں کریں', animate:'حرکت دیں' },
  pa: { chooseReport:'رپورٹ منتخب کرو تاکہ کلیدی الفاظ خودکار پتہ لگ سکیں۔', noReport:'کوئی رپورٹ منتخب نہیں ہوئی۔', detecting:'کلیدی الفاظ پتہ لگ رہے ہیں...', noKeywords:'کوئی مخصوص عضو نہیں ملا۔', generalTip:'صحت عام: پانی زیادہ پئیں، متوازن غذا، باقاعدہ ورزش، معمول چیک اپ۔', animateNone:'کوئی عضو حرکت دینے کے لیے نہیں۔', highlighted:'نمایاں شدہ: ', animating:'حرکت دے رہا ہے: ', animationStopped:'حرکت بند ہوگئی۔', zoom:'زوم', resetZoom:'زوم ری سیٹ', rotate:'گھماؤ', resetRotate:'گھماؤ ری سیٹ', highlight:'عضو نمایاں کریں', animate:'حرکت دیں' }
};

let currentLang='en';
const reportSelect=document.getElementById('reportSelect');
const langSelect=document.getElementById('langSelect');
const statusMsg=document.getElementById('statusMsg');
const tipsList=document.getElementById('tipsList');
const extractedTextDiv=document.getElementById('extractedText');
const btnHighlight=document.getElementById('btnHighlight');
const btnZoom=document.getElementById('btnZoom');
const btnRotate=document.getElementById('btnRotate');
const btnAnimate=document.getElementById('btnAnimate');
const bodySvg=document.getElementById('bodySvg');

let detectedOrgans=[];
let zoomed=false;
let rotated=false;

// organ keyword map with multilingual tips
const KEY_MAP = [
  {keywords:['heart','cardiac'], organ:'heart', tip:{en:'Heart: reduce salt, follow-up with cardiologist.', ur:'دل: نمک کم کریں، کارڈیولوجسٹ سے رجوع کریں۔', pa:'دل: نمک گھٹاؤ، کارڈیولوجسٹ نال رابطہ کرو۔'}},
  {keywords:['lung','lungs'], organ:'lungs', tip:{en:'Lungs: avoid smoking, consult pulmonologist.', ur:'پھیپھڑے: سگریٹ نوشی سے پرہیز، پلمونولوجسٹ سے رجوع کریں۔', pa:'پھیپھڑے: سگریٹ نوشی توں بچو، پلمونولوجسٹ نال رجوع کرو۔'}},
  {keywords:['kidney','renal'], organ:'kidneys', tip:{en:'Kidneys: stay hydrated, consult nephrologist.', ur:'گردے: پانی زیادہ پئیں، نیفرولوجسٹ سے رجوع کریں۔', pa:'گردے: پانی زیادہ پیو، نیفرولوجسٹ نال رجوع کرو۔'}},
  {keywords:['liver','hepatic'], organ:'liver', tip:{en:'Liver: avoid alcohol, eat light meals.', ur:'جگر: الکحل سے پرہیز، ہلکی غذا کھائیں۔', pa:'جگر: الکحل توں بچو، ہلکا کھانا کھاؤ۔'}},
  {keywords:['brain','neurology'], organ:'brain', tip:{en:'Brain: maintain BP & sugar control.', ur:'دماغ: بلڈ پریشر اور شوگر کنٹرول رکھیں۔', pa:'دماغ: بلڈ پریشر تے شوگر کنٹرول رکھو۔'}},
  {keywords:['stomach','gastric'], organ:'stomach', tip:{en:'Stomach: small meals, avoid spicy food.', ur:'معدہ: چھوٹے کھانے، مصالحہ دار غذا سے پرہیز۔', pa:'معدہ: چھوٹے کھانے کھاؤ، مصالحہ توں بچو۔'}},
  {keywords:['bone','fracture','hip'], organ:'bones', tip:{en:'Bones: rest, take calcium & vitamin D.', ur:'ہڈیاں: آرام کریں، کیلشیم اور وٹامن ڈی لیں۔', pa:'ہڈیاں: آرام کرو، کیلشیم تے وٹامن ڈی لو۔'}}
];

function t(key){ return LANG[currentLang][key] || key; }
function normalizeText(t){ return (t||'').toLowerCase().replace(/\s+/g,' '); }

function detectFromText(text, filename){
  const low = normalizeText(text)+' '+normalizeText(filename);
  const found = new Set();
  const tips=[];
  KEY_MAP.forEach(map=>{ for(const kw of map.keywords){ if(low.indexOf(kw)!==-1){ found.add(map.organ); tips.push(map.tip[currentLang]); break; } } });
  return {organs:Array.from(found), tips:tips};
}

function clearHighlights(){ document.querySelectorAll('.org').forEach(el=>{ el.classList.remove('active'); el.classList.remove('pulse'); }); }
function highlightOrg(organ){ document.querySelectorAll('[data-organ="'+organ+'"]').forEach(n=>n.classList.add('active')); }

function updateUIText(){
  btnHighlight.textContent=t('highlight');
  btnZoom.textContent=zoomed?t('resetZoom'):t('zoom');
  btnRotate.textContent=rotated?t('resetRotate'):t('rotate');
  btnAnimate.textContent=t('animate');
  if(!reportSelect.value) statusMsg.textContent=t('chooseReport');
}

// LANGUAGE SWITCH
langSelect.addEventListener('change', () => {
  currentLang = langSelect.value;
  updateUIText();
  if(detectedOrgans.length>0){
    clearHighlights();
    detectedOrgans.forEach(o => highlightOrg(o));
    let html='';
    KEY_MAP.forEach(map => {
      if(detectedOrgans.includes(map.organ)) html+='<div class="tip-item">'+map.tip[currentLang]+'</div>';
    });
    tipsList.innerHTML=html;
  }
});

// REPORT SELECTION
reportSelect.addEventListener('change', async function(){
  clearHighlights();
  detectedOrgans=[];
  tipsList.innerHTML=`<em>${t('detecting')}</em>`;
  extractedTextDiv.textContent=t('detecting');
  statusMsg.textContent=t('detecting');

  const id=this.value;
  if(!id){ tipsList.innerHTML=`<em>${t('noReport')}</em>`; extractedTextDiv.textContent=t('noReport'); statusMsg.textContent=t('chooseReport'); return; }

  try{
    const resp=await fetch('get_report_text.php?id='+encodeURIComponent(id));
    if(!resp.ok) throw new Error('Network response not OK');
    const j=await resp.json();
    if(!j.ok){ extractedTextDiv.textContent=j.error||t('noReport'); tipsList.innerHTML=`<em>${t('noKeywords')}</em>`; statusMsg.textContent=t('noKeywords'); return; }

    const text=j.text||''; const filename=j.filename||'';
    extractedTextDiv.textContent=text||'(no extractable text)';

    const result=detectFromText(text, filename);
    detectedOrgans=result.organs;

    if(detectedOrgans.length===0){
      tipsList.innerHTML=`<em>${t('noKeywords')}</em><div class="tip-item">${t('generalTip')}</div>`;
      statusMsg.textContent=t('noKeywords');
    } else {
      let html='';
      result.tips.forEach(tip=>{ html+='<div class="tip-item">'+tip+'</div>'; });
      tipsList.innerHTML=html;
      statusMsg.textContent=t('highlighted')+detectedOrgans.join(', ');
      clearHighlights();
      detectedOrgans.forEach(o=>highlightOrg(o));
    }
  }catch(err){
    extractedTextDiv.textContent='Error: '+err.message;
    tipsList.innerHTML=`<em>${t('noKeywords')}</em>`;
    statusMsg.textContent='Error';
    console.error(err);
  }
});

// BUTTONS
btnHighlight.addEventListener('click', ()=>{ clearHighlights(); if(detectedOrgans.length===0){ statusMsg.textContent=t('noKeywords'); return; } detectedOrgans.forEach(o=>highlightOrg(o)); statusMsg.textContent=t('highlighted')+detectedOrgans.join(', '); });
btnZoom.addEventListener('click', ()=>{ zoomed=!zoomed; bodySvg.style.transform=zoomed?'scale(1.35)':'scale(1)'; btnZoom.textContent=zoomed?t('resetZoom'):t('zoom'); });
btnRotate.addEventListener('click', ()=>{ rotated=!rotated; bodySvg.style.transform=rotated?'rotate(15deg)':'rotate(0deg)'; btnRotate.textContent=rotated?t('resetRotate'):t('rotate'); });
btnAnimate.addEventListener('click', ()=>{ if(detectedOrgans.length===0){ statusMsg.textContent=t('animateNone'); return; } detectedOrgans.forEach(o=>{ document.querySelectorAll('[data-organ="'+o+'"]').forEach(n=>n.classList.add('pulse')); }); statusMsg.textContent=t('animating')+detectedOrgans.join(', '); setTimeout(()=>{ document.querySelectorAll('.org').forEach(n=>n.classList.remove('pulse')); statusMsg.textContent=t('animationStopped'); },3000); });

updateUIText();
</script>
</body>
</html>
