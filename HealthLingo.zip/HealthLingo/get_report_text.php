<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if(!isset($_SESSION['user_id'])){
    echo json_encode(['ok'=>false,'error'=>'Not logged in']);
    exit();
}

include 'db.php'; // mysqli $conn
require 'vendor/autoload.php';

use Stichoza\GoogleTranslate\GoogleTranslate;

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$lang = $_GET['lang'] ?? 'en'; // en, ur, pa

if($id <= 0){
    echo json_encode(['ok'=>false,'error'=>'Invalid id']);
    exit();
}

// fetch report record (ensure belongs to user)
$stmt = $conn->prepare("SELECT report_file, report_title FROM medical_reports WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $id, $_SESSION['user_id']);
$stmt->execute();
$res = $stmt->get_result();
if(!$rec = $res->fetch_assoc()){
    echo json_encode(['ok'=>false,'error'=>'Report not found']);
    exit();
}
$stmt->close();

$filename = $rec['report_file'];
$filepath = __DIR__ . '/uploads/' . $filename;
$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

if(!file_exists($filepath)){
    echo json_encode(['ok'=>false,'error'=>'File not found', 'filename'=>$filename]);
    exit();
}

// extract text
$text = '';
try{
    if($ext === 'txt'){
        $text = file_get_contents($filepath);
    } elseif($ext === 'doc' || $ext === 'docx'){
        $phpWord = \PhpOffice\PhpWord\IOFactory::load($filepath);
        foreach($phpWord->getSections() as $section){
            foreach($section->getElements() as $el){
                if(method_exists($el,'getText')) $text .= $el->getText()." ";
            }
        }
    } elseif($ext === 'pdf'){
        $parser = new \Smalot\PdfParser\Parser();
        $pdf = $parser->parseFile($filepath);
        $text = $pdf->getText();
    }
}catch(Exception $e){
    $text = '';
}

// Translate if needed
if($lang !== 'en' && !empty($text)){
    try{
        $tr = new GoogleTranslate();
        $tr->setTarget($lang=='ur'?'ur':'pa');
        $text = $tr->translate($text);

        // Optional: Punjabi → Shahmukhi
        if($lang=='pa'){
            function gurmukhiToShahmukhi($text){
                $map = [
                    'ਅ'=>'ا','ਆ'=>'آ','ਇ'=>'اِ','ਈ'=>'ای','ਉ'=>'او','ਊ'=>'اُو',
                    'ਏ'=>'اے','ਐ'=>'آے','ਓ'=>'او','ਔ'=>'اؤ',
                    'ਕ'=>'ک','ਖ'=>'کھ','ਗ'=>'گ','ਘ'=>'گھ','ਙ'=>'نگ',
                    'ਚ'=>'چ','ਛ'=>'چھ','ਜ'=>'ج','ਝ'=>'جھ','ਞ'=>'نج',
                    'ਟ'=>'ٹ','ਠ'=>'ٹھ','ਡ'=>'ڈ','ਢ'=>'ڈھ','ਣ'=>'ن',
                    'ਤ'=>'ت','ਥ'=>'تھ','ਦ'=>'د','ਧ'=>'دھ','ਨ'=>'ن',
                    'ਪ'=>'پ','ਫ'=>'ف','ਬ'=>'ب','ਭ'=>'بھ','ਮ'=>'م',
                    'ਯ'=>'ی','ਰ'=>'ر','ਲ'=>'ل','ਵ'=>'و',
                    'ਸ'=>'س','ਹ'=>'ہ',
                    'ਖ਼'=>'خ','ਗ਼'=>'غ','ਜ਼'=>'ز','ਫ਼'=>'ف','ਸ਼'=>'ش',
                    'ਾ'=>'ا','ਿ'=>'ِ','ੀ'=>'ی','ੁ'=>'ُ','ੂ'=>'ُو',
                    'ੇ'=>'ے','ੈ'=>'َے','ੋ'=>'و','ੌ'=>'ؤ','ੰ'=>'ں','ਂ'=>'ں','ੱ'=>'ّ'
                ];
                return strtr($text, $map);
            }
            $text = gurmukhiToShahmukhi($text);
        }
    }catch(Exception $e){
        // fallback to original text
    }
}

echo json_encode(['ok'=>true,'text'=>$text,'filename'=>$rec['report_title']]);
exit();
?>
