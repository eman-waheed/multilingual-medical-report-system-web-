<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user info
$user = [];
$result = mysqli_query($conn, "SELECT * FROM users WHERE id = $user_id LIMIT 1");
if ($result && mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
}

// Message variable
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $comments = mysqli_real_escape_string($conn, $_POST['comments']);

    $sql = "INSERT INTO feedback (user_id, feedback_text)
            VALUES ('$user_id', '$comments')";

    if (mysqli_query($conn, $sql)) {
        $message = "Feedback submitted successfully!";
    } else {
        $message = "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HealthLingo - Feedback</title>

<style>
body {
  margin: 0;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background: url("images/Patientbg.png") no-repeat center center fixed;
  background-size: cover;
  display: flex;
  height: 100vh;
  overflow: hidden;
  color: #004d40;
}
.sidebar {
  width: 250px;
  background: rgba(0, 121, 107, 0.88);
  color: white;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
}
.sidebar h2 {
  font-size: 22px;
  margin-bottom: 25px;
}
.back-btn {
  margin-top: auto;
  padding: 10px 20px;
  background: white;
  color: rgba(0, 121, 107, 0.85);
  border: none;
  border-radius: 6px;
  font-weight: bold;
  cursor: pointer;
  width: 100%;
}
.main {
  flex: 1;
  padding: 30px;
  background: rgba(255, 255, 255, 0.3);
}
.feedback-form {
  background: white;
  padding: 25px;
  border-radius: 12px;
  max-width: 500px;
}
.feedback-form label {
  margin-top: 12px;
  display: block;
  font-weight: 600;
}
.feedback-form input,
.feedback-form textarea {
  width: 100%;
  padding: 10px;
  margin-top: 6px;
}
.feedback-form textarea {
  height: 100px;
  resize: none;
}
.feedback-form button {
  margin-top: 18px;
  width: 100%;
  padding: 10px;
  background: rgba(0, 121, 107, 0.85);
  color: white;
  border: none;
  border-radius: 6px;
  font-weight: bold;
}
.message {
  margin-bottom: 15px;
  color: green;
  font-weight: bold;
}
</style>
</head>

<body>
<div class="sidebar">
  <h2>HealthLingo</h2>
  <button class="back-btn" onclick="window.location.href='patient_dashboard.php'">
    ⬅ Back to Dashboard
  </button>
</div>

<div class="main">
<h1>Patient Feedback</h1>

<?php if ($message != '') echo "<div class='message'>$message</div>"; ?>

<form class="feedback-form" method="POST">
  <label>Your Name:</label>
  <input type="text" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" disabled>

  <label>Comments:</label>
  <textarea name="comments" placeholder="Write your feedback here..." required></textarea>

  <button type="submit">📩 Submit Feedback</button>
</form>
</div>

</body>
</html>
