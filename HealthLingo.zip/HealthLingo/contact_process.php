<?php
// contact_process.php
session_start();
include 'db.php'; // include your database connection file

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name'] ?? '');
    $email = mysqli_real_escape_string($conn, $_POST['email'] ?? '');
    $message = mysqli_real_escape_string($conn, $_POST['message'] ?? '');

    if(!empty($name) && !empty($email) && !empty($message)) {
        $sql = "INSERT INTO contact_messages (name, email, message) VALUES ('$name', '$email', '$message')";
        if(mysqli_query($conn, $sql)) {
            // Redirect back with success message
            $_SESSION['contact_msg'] = "Thank you, $name! Your message has been received.";
        } else {
            $_SESSION['contact_msg'] = "Error: " . mysqli_error($conn);
        }
    } else {
        $_SESSION['contact_msg'] = "Please fill in all fields.";
    }

    // Redirect back to homescreen.php
    header("Location: homescreen.php#contact");
    exit();
} else {
    echo "Invalid request.";
}
?>
