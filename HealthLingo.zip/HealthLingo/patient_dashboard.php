<?php 
session_start(); 
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}  

include 'db.php'; 
require 'vendor/autoload.php';  

use Stichoza\GoogleTranslate\GoogleTranslate; 
use PhpOffice\PhpWord\IOFactory; 
use Smalot\PdfParser\Parser as PdfParser;  

$user_name = $_SESSION['user_name']; 
$user_id = $_SESSION['user_id'];  

// Fetch last 5 medical reports 
$reports = []; 
$result = mysqli_query($conn, "SELECT * FROM medical_reports WHERE user_id = $user_id ORDER BY created_at DESC LIMIT 5"); 
if($result){
    while($row = mysqli_fetch_assoc($result)){
        $reports[] = $row;
    }
}  

// Extract text from file 
function extractText($filepath, $ext){
    $text = "";
    try{
        if($ext=='pdf'){
            $parser = new PdfParser();
            $pdf = $parser->parseFile($filepath);
            $text = $pdf->getText();
        } elseif($ext=='doc' || $ext=='docx'){
            $phpWord = IOFactory::load($filepath);
            foreach($phpWord->getSections() as $section){
                foreach($section->getElements() as $el){
                    if(method_exists($el,'getText')) $text .= $el->getText()." ";
                }
            }
        } elseif($ext=='txt'){
            $text = file_get_contents($filepath);
        }
    } catch(Exception $e){ return ""; }
    return $text;
}  

// Gurmukhi → Shahmukhi (Pakistani Punjabi)
function gurmukhiToShahmukhi($text){
    $map = [
        'ਅ'=>'ا','ਆ'=>'آ','ਇ'=>'اِ','ਈ'=>'ای','ਉ'=>'او','ਊ'=>'اُو',
        'ਏ'=>'اے','ਐ'=>'آے','ਓ'=>'او','ਔ'=>'اؤ',
        'ਕ'=>'ک','ਖ'=>'کھ','ਗ'=>'گ','ਘ'=>'گھ','ਙ'=>'نگ',
        'ਚ'=>'چ','ਛ'=>'چھ','ਜ'=>'ج','ਝ'=>'جھ','ਞ'=>'نج',
        'ਟ'=>'ٹ','ਠ'=>'ٹھ','ਡ'=>'ڈ','ਢ'=>'ڈھ','ਣ'=>'ن',
        'ਤ'=>'ت','ਥ'=>'تھ','ਦ'=>'د','ਧ'=>'دھ','ਨ'=>'ن',
        'ਪ'=>'پ','ਫ'=>'ف','ਬ'=>'ب','ਭ'=>'بھ','ਮ'=>'م',
        'ਯ'=>'ی','ਰ'=>'ر','ਲ'=>'ل','ਵ'=>'و',
        'ਸ'=>'س','ਹ'=>'ہ',
        'ਖ਼'=>'خ','ਗ਼'=>'غ','ਜ਼'=>'ز','ਫ਼'=>'ف','ਸ਼'=>'ش',
        'ਾ'=>'ا','ਿ'=>'ِ','ੀ'=>'ی','ੁ'=>'ُ','ੂ'=>'ُو',
        'ੇ'=>'ے','ੈ'=>'َے','ੋ'=>'و','ੌ'=>'ؤ','ੰ'=>'ں','ਂ'=>'ں','ੱ'=>'ّ'
    ];
    return strtr($text, $map);
}

// Translate safely 
function translateText($text, $lang){
    $tr = new GoogleTranslate();

    if($lang=='pa'){ // Punjabi → Shahmukhi
        $tr->setTarget('pa'); 
        $gurmukhi = $tr->translate($text);
        return gurmukhiToShahmukhi($gurmukhi);

    } elseif($lang=='ur'){
        $tr->setTarget('ur'); 
        return $tr->translate($text);

    } else {
        return $text; // English
    }
}  

// Severity function
function getSeverityClass($sev){
    switch($sev){
        case 'mild': return ['normal','Mild'];
        case 'moderate': return ['moderate','Moderate'];
        case 'severe': return ['severe','Severe'];
        default: return ['normal','Mild'];
    }
}  

$lang = $_GET['lang'] ?? 'en'; 
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
<meta charset="UTF-8"> 
<title>Patient Dashboard</title> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Gurmukhi&family=Noto+Nastaliq+Urdu&display=swap" rel="stylesheet"> 
<style> 
body { 
    margin:0; 
    font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; 
    background:#f4f4f4; 
    display:flex; 
    color:#004d40; 
} 

.sidebar { 
    width:250px; 
    background:#00796b; 
    color:white; 
    display:flex; 
    flex-direction:column; 
    padding:25px 20px; 
    border-top-right-radius:25px; 
    border-bottom-right-radius:25px; 
} 

.sidebar h2 { 
    text-align:center; 
    margin-bottom:25px; 
    font-size:22px; 
} 

.sidebar ul { 
    list-style:none; 
    padding:0; 
} 

.sidebar ul li { 
    margin:10px 0; 
} 

.sidebar ul li button { 
    width:100%; 
    padding:10px; 
    border:none; 
    border-radius:8px; 
    cursor:pointer; 
    font-weight:600; 
} 

.sidebar ul li button.normal { 
    background: rgba(200,255,200,0.6); 
    border-left:6px solid #2e7d32; 
} 

.sidebar ul li button.moderate { 
    background: rgba(255,255,200,0.6); 
    border-left:6px solid #f9a825; 
} 

.sidebar ul li button.severe { 
    background: rgba(255,200,200,0.6); 
    border-left:6px solid #d32f2f; 
} 

.sidebar ul li button:hover { 
    opacity:0.9; 
} 

.links a {
    display: block;
    margin: 8px 0;
    padding: 10px 12px;
    background: white;       
    color: #00796b;          
    font-weight: 600;
    border-radius: 8px;
    text-decoration: none;
    text-align: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    transition: 0.2s;
}

.links a:hover {
    background: #e0f2f1;
    transform: translateY(-2px);
}

.main { 
    flex:1; 
    padding:30px; 
    overflow-y:auto; 
    display:flex; 
    flex-direction:column; 
    background:rgba(255,255,255,0.3); 
    border-top-left-radius:25px; 
    border-bottom-left-radius:25px; 
    backdrop-filter:blur(5px); 
} 

header { 
    display:flex; 
    justify-content:space-between; 
    align-items:center; 
} 

header h1 { 
    margin:0; 
    color:#00796b; 
    font-size:26px; 
} 

.lang-select { 
    padding:8px; 
    border-radius:6px; 
    border:1px solid #ccc; 
    font-weight:500; 
} 

.report-card { 
    padding:15px; 
    border-radius:10px; 
    margin:10px 0; 
    box-shadow:0 2px 5px rgba(0,0,0,0.1); 
    max-width:600px; 
    font-weight:600; 
} 

.report-card.normal { 
    background: rgba(200,255,200,0.6); 
    border-left:6px solid #2e7d32; 
} 

.report-card.moderate { 
    background: rgba(255,255,200,0.6); 
    border-left:6px solid #f9a825; 
} 

.report-card.severe { 
    background: rgba(255,200,200,0.6); 
    border-left:6px solid #d32f2f; 
} 

.reports a { 
    display:inline-block; 
    margin-right:10px; 
    padding:6px 10px; 
    background:#00796b; 
    color:white; 
    border-radius:5px; 
    text-decoration:none; 
} 

.punjabi, .urdu { 
    font-family:'Noto Nastaliq Urdu',serif; 
    direction:rtl; 
} 
</style> 
</head> 
<body> 

<div class="sidebar"> 
    <h2>Past Reports</h2> 
    <ul> 
    <?php 
    if(count($reports)>0){     
        foreach($reports as $r){         
            $status_class = $r['severity'];         
            echo "<li><button class='{$status_class}'>".htmlspecialchars($r['report_title'])." - ".date('M d', strtotime($r['created_at']))."</button></li>";     
        } 
    }else{     
        echo "<li><button class='normal'>No reports found</button></li>"; 
    } 
    ?> 
    </ul> 
    <div class="links">     
        <a href="report_upload.php">Reports</a>     
        <a href="feedback.php">Feedback</a>     
        <a href="secure_sharing_screen.php">Screen Sharing</a>     
        <a href="logout.php">Logout</a> 
    </div> 
</div>  

<div class="main"> 
<header> 
<h1>Welcome, <?= htmlspecialchars($user_name) ?></h1> 
<form method="GET"> 
<select class="lang-select" name="lang" onchange="this.form.submit()"> 
<option value="en" <?= $lang=='en'?'selected':'' ?>>English</option> 
<option value="ur" <?= $lang=='ur'?'selected':'' ?>>Urdu</option> 
<option value="pa" <?= $lang=='pa'?'selected':'' ?>>Punjabi (Shahmukhi)</option> 
</select> 
</form> 
</header> 

<h2>Recent Medical Updates</h2>  

<?php 
foreach($reports as $r){     
    list($cls,$sev_text) = getSeverityClass($r['severity']);     
    $filepath = 'uploads/'.$r['report_file'];     
    $ext = strtolower(pathinfo($r['report_file'],PATHINFO_EXTENSION));     
    $original_text = extractText($filepath,$ext);      

    if($lang=='en') $display_text = $original_text;     
    else $display_text = translateText($original_text,$lang);      

    $lang_class = ($lang=='ur' || $lang=='pa') ? 'urdu' : '';     
    $translated_file = "uploads/".$user_id."_".time()."_$lang.txt";     
    file_put_contents($translated_file, $display_text);     
?>      

<div class="report-card <?= $cls ?> <?= $lang_class ?>">         
    <h3><?= htmlspecialchars($r['report_title']) ?></h3>         
    <p><strong>Severity:</strong> <?= $sev_text ?></p>         
    <p><?= nl2br(htmlspecialchars($display_text)) ?></p>         
    <div class="reports">             
        <a href="<?= $filepath ?>" download>Download Original</a>             
        <a href="<?= $translated_file ?>" download>Download <?= strtoupper($lang) ?></a>         
    </div>     
</div> 
<?php } ?>  

</div> 
</body> 
</html>
