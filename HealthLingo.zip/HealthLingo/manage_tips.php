<?php
session_start();
include 'db.php'; // your mysqli connection

// Check admin login
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: admin-login.php");
    exit();
}

// Detect selected language
$language = $_GET['lang'] ?? 'en'; // default English
switch($language){
    case 'hi': $tip_field = 'tip_hi'; break;
    case 'pa': $tip_field = 'tip_pa'; break;
    case 'ur': $tip_field = 'tip_ur'; break;
    default: $tip_field = 'tip_en';
}

// Fetch tips
$sql = "SELECT organ, tip_en, tip_hi, tip_pa, tip_ur FROM health_tips ORDER BY organ ASC";
$result = mysqli_query($conn, $sql);
$tips = [];
while($row = mysqli_fetch_assoc($result)){
    // safe fallback for missing fields
    $tips[] = [
        'organ' => $row['organ'] ?? '',
        'tip' => $row[$tip_field] ?? $row['tip_en'] ?? '',
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Health Tips - Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css"/>
<style>
body { font-family: Arial, sans-serif; background:#f4f7f6; }
.container { margin-top:40px; }
.language-select { float:right; }
.table th, .table td { vertical-align: middle !important; }
</style>
</head>
<body>

<div class="container">
    <h2>Manage Health Tips</h2>
    
    <div class="language-select mb-3">
        <form method="get" action="">
            <label for="lang">Language: </label>
            <select name="lang" id="lang" onchange="this.form.submit()">
                <option value="en" <?php if($language=='en') echo 'selected'; ?>>English</option>
                <option value="hi" <?php if($language=='hi') echo 'selected'; ?>>Hindi</option>
                <option value="pa" <?php if($language=='pa') echo 'selected'; ?>>Punjabi</option>
                <option value="ur" <?php if($language=='ur') echo 'selected'; ?>>Urdu</option>
            </select>
        </form>
    </div>

    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th>#</th>
                <th>Organ</th>
                <th>Tip (<?php echo strtoupper($language); ?>)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($tips as $i => $t): ?>
                <tr>
                    <td><?php echo $i+1; ?></td>
                    <td><?php echo htmlspecialchars($t['organ']); ?></td>
                    <td><?php echo htmlspecialchars($t['tip']); ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if(count($tips) === 0): ?>
                <tr>
                    <td colspan="3" class="text-center">No tips found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>
