<?php
session_start();
include 'db.php'; // your database connection

// Admin check
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: admin-login.php");
    exit();
}

if(!isset($_GET['id'])){
    die("User ID not provided.");
}

$id = (int)$_GET['id'];
$res = mysqli_query($conn, "SELECT * FROM users WHERE id=$id LIMIT 1");
$user = mysqli_fetch_assoc($res);
if(!$user){
    die("User not found.");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>View User</title>
</head>
<body>
<h2>User Details</h2>
<p><strong>ID:</strong> <?php echo $user['id']; ?></p>
<p><strong>Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
<p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
<p><strong>Role:</strong> <?php echo $user['role']; ?></p>
<p><strong>Registered At:</strong> <?php echo $user['created_at']; ?></p>
<a href="admin-panel.php">Back to Admin Panel</a>
</body>
</html>
