<?php
session_start();
include 'db.php'; // Your database connection

// Check if admin or patient
if(!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin','patient'])){
    die("Access denied.");
}

// Check if report ID is provided
if(!isset($_GET['id'])){
    die("Report ID missing.");
}

$report_id = intval($_GET['id']);

// Fetch report
$stmt = $conn->prepare("SELECT r.report_title, r.report_file, u.name AS user_name 
                        FROM medical_reports r
                        JOIN users u ON r.user_id = u.id
                        WHERE r.id = ?");
$stmt->bind_param("i", $report_id);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows === 0){
    die("Report not found.");
}

$report = $result->fetch_assoc();
$filepath = 'uploads/' . $report['report_file'];

// Check if file exists
if(!file_exists($filepath)){
    die("File not found on server.");
}

// Get file extension
$ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));

// Serve file appropriately
if($ext === 'pdf'){
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . $report['report_file'] . '"');
    readfile($filepath);
} elseif(in_array($ext, ['doc', 'docx', 'txt'])){
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $report['report_file'] . '"');
    readfile($filepath);
} else {
    die("Unsupported file type.");
}
?>
