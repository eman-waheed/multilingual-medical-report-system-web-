<?php
session_start();
include 'db.php'; // Database connection

// If not logged in as admin, redirect to login
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: admin-login.php");
    exit();
}

// Fetch all users
$users = [];
$users_res = mysqli_query($conn, "SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC");
while($u = mysqli_fetch_assoc($users_res)){
    $users[] = $u;
}

// Fetch recent reports
$reports = [];
$rep_res = mysqli_query($conn, "SELECT r.id, r.report_title, r.report_file, r.created_at, u.name AS user_name 
                                FROM medical_reports r
                                JOIN users u ON r.user_id = u.id
                                ORDER BY r.created_at DESC LIMIT 20");
while($r = mysqli_fetch_assoc($rep_res)){
    $reports[] = $r;
}

// Fetch health tips
$tips = [];
$tips_res = mysqli_query($conn, "
    SELECT pht.*, u.name AS user_name, mr.report_title
    FROM patient_health_tips pht
    JOIN users u ON pht.user_id = u.id
    JOIN medical_reports mr ON pht.report_id = mr.id
    ORDER BY pht.created_at DESC
");

while($t = mysqli_fetch_assoc($tips_res)){
    $tips[] = $t;
}

// Fetch feedback (rating removed)
$feedbacks = [];
$fb_res = mysqli_query($conn, "SELECT f.id, u.name AS user_name, f.feedback_text, f.created_at 
                               FROM feedback f
                               JOIN users u ON f.user_id = u.id
                               ORDER BY f.created_at DESC");
while($f = mysqli_fetch_assoc($fb_res)){
    $feedbacks[] = $f;
}

// Fetch contact messages
$contact_messages = [];
$contact_res = mysqli_query($conn, "SELECT * FROM contact_messages ORDER BY created_at DESC");
while($msg = mysqli_fetch_assoc($contact_res)){
    $contact_messages[] = $msg;
}

// Fetch report chats
$report_chats = [];
$chat_res = mysqli_query($conn, "
    SELECT rc.id, rc.report_id, rc.message, rc.created_at, 
           u.name AS user_name, r.report_title
    FROM report_chats rc
    JOIN users u ON rc.user_id = u.id
    JOIN medical_reports r ON rc.report_id = r.id
    ORDER BY rc.created_at DESC
");
while($row = mysqli_fetch_assoc($chat_res)){
    $report_chats[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel - HealthLingo</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
<style>
body { font-family: 'Poppins', sans-serif; background:#f4f7f6; }
.header { background:#00796b; color:#fff; padding:12px 20px; }
.header h2 { margin:0; display:inline-block; }
.nav a { color:#fff; margin-left:10px; }
.table th, .table td { vertical-align:middle; }
.section { background:#fff; padding:20px; margin-bottom:20px; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
</style>
</head>
<body>

<header class="header d-flex justify-content-between align-items-center">
    <h2>Admin Panel</h2>
    <nav class="nav">
        <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
    </nav>
</header>

<div class="container mt-4">
    <h4>Welcome, Admin!</h4>
    <p>Monitor users, reports, health tips, feedback, contact messages, and report chats below.</p>

    <!-- Users Section -->
    <div class="section">
        <h5>Registered Users</h5>
        <table class="table table-bordered table-striped mt-3">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Registered At</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $u): ?>
                <tr>
                    <td><?php echo $u['id']; ?></td>
                    <td><?php echo htmlspecialchars($u['name']); ?></td>
                    <td><?php echo htmlspecialchars($u['email']); ?></td>
                    <td><?php echo $u['role']; ?></td>
                    <td><?php echo $u['created_at']; ?></td>
                    <td>
                        <a href="view_user.php?id=<?php echo $u['id']; ?>" class="btn btn-info btn-sm">View</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Reports Section -->
    <div class="section">
        <h5>Recent Reports</h5>
        <table class="table table-bordered table-striped mt-3">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th><th>Title</th><th>User</th><th>File</th><th>Uploaded At</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($reports as $r): ?>
                <tr>
                    <td><?php echo $r['id']; ?></td>
                    <td><?php echo htmlspecialchars($r['report_title']); ?></td>
                    <td><?php echo htmlspecialchars($r['user_name']); ?></td>
                    <td><a href="uploads/<?php echo htmlspecialchars($r['report_file']); ?>" target="_blank">View</a></td>
                    <td><?php echo $r['created_at']; ?></td>
                    <td>
                        <a href="delete_report.php?id=<?php echo $r['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this report?');">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Health Tips Section -->
    <div class="section">
        <h5>Health Tips Overview</h5>
        <table class="table table-bordered table-striped mt-3">
            <thead class="thead-dark">
                <tr>
                    <th>Organ</th><th>Tip (EN)</th><th>Tip (UR)</th><th>Tip (PN)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($tips as $t): ?>
                <tr>
                    <td><?php echo htmlspecialchars($t['organ']); ?></td>
                    <td><?php echo htmlspecialchars($t['tip_en']); ?></td>
                    <td><?php echo htmlspecialchars($t['tip_ur'] ?? ''); ?></td>
                    <td><?php echo htmlspecialchars($t['tip_pn'] ?? ''); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Feedback Section -->
    <div class="section">
        <h5>User Feedback</h5>
        <table class="table table-bordered table-striped mt-3">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th><th>User</th><th>Feedback</th><th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($feedbacks as $f): ?>
                <tr>
                    <td><?php echo $f['id']; ?></td>
                    <td><?php echo htmlspecialchars($f['user_name']); ?></td>
                    <td><?php echo htmlspecialchars($f['feedback_text']); ?></td>
                    <td><?php echo $f['created_at']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Contact Messages Section -->
    <div class="section">
        <h5>Contact Messages</h5>
        <table class="table table-bordered table-striped mt-3">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th><th>Name</th><th>Email</th><th>Message</th><th>Received At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($contact_messages as $msg): ?>
                <tr>
                    <td><?php echo $msg['id']; ?></td>
                    <td><?php echo htmlspecialchars($msg['name']); ?></td>
                    <td><?php echo htmlspecialchars($msg['email']); ?></td>
                    <td><?php echo htmlspecialchars($msg['message']); ?></td>
                    <td><?php echo $msg['created_at']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Report Chats / Secure Links Section -->
    <div class="section">
        <h5>Report Chats / Secure Links</h5>
        <table class="table table-bordered table-striped mt-3">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Report</th>
                    <th>User</th>
                    <th>Message</th>
                    <th>Secure Link</th>
                    <th>Sent At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($report_chats as $c): ?>
                <tr>
                    <td><?php echo $c['id']; ?></td>
                    <td><?php echo htmlspecialchars($c['report_title']); ?></td>
                    <td><?php echo htmlspecialchars($c['user_name']); ?></td>
                    <td><?php echo htmlspecialchars($c['message']); ?></td>
                    <td>
                        <a href="https://secure.healthlingo.com/report/<?php echo $c['report_id']; ?>" target="_blank">Link</a>
                    </td>
                    <td><?php echo $c['created_at']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>
